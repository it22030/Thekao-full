from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, get_user_model
from django.contrib.auth.forms import AuthenticationForm
from django.views.generic import CreateView
from django.urls import reverse_lazy
from django.contrib.auth.views import LoginView
from django.contrib import messages

from accounts.forms import UserRegistrationForm,RiderRegisterForm

User = get_user_model()

# ======================
# RIDER REGISTER
# ======================
class RiderRegisterView(CreateView):
    model = User
    form_class = RiderRegistrationForm
    template_name = 'accounts/rider_register.html'
    success_url = reverse_lazy('rider_dashboard')

    def form_valid(self, form):
        # 🔐 Never trust frontend/forms fully
        user = form.save(commit=False)
        user.role = 'rider'
        user.save()

        login(self.request, user)
        return redirect(self.success_url)


# ======================
# RIDER LOGIN
# ======================
class RiderLoginView(LoginView):
    template_name = 'accounts/rider_login.html'
    redirect_authenticated_user = True

    def form_valid(self, form):
        user = form.get_user()

        # 🚨 Riders only
        if getattr(user, 'role', None) != 'rider':
            messages.error(self.request, "Access denied. Riders only.")
            return redirect('rider_login')

        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('rider_dashboard')


# ======================
# NORMAL USER REGISTER
# ======================
def register_view(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserRegistrationForm()

    return render(request, 'accounts/register.html', {'form': form})


# ======================
# NORMAL LOGIN
# ======================
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)

            if user.is_superuser or getattr(user, 'role', None) == 'admin':
                return redirect('admin_dashboard')
            elif getattr(user, 'role', None) == 'rider':
                return redirect('rider_dashboard')

            return redirect('home')
    else:
        form = AuthenticationForm()

    return render(request, 'accounts/login.html', {'form': form})


# ======================
# LOGOUT
# ======================
def logout_view(request):
    logout(request)
    return redirect('home')
