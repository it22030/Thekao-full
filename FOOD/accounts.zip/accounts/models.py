from django.contrib.auth.models import AbstractUser
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver


class User(AbstractUser):
    role = models.CharField(
        max_length=20,
        choices=[
            ('customer', 'Customer'),
            ('restaurant', 'Restaurant'),
            ('admin', 'Admin'),
            ('rider', 'Rider'),
            ('seller', 'Seller'),
        ],
        default='customer'
    )


class RiderProfile(models.Model):
    RIDER_TYPE_CHOICES = [
        ('food', 'Food Delivery'),
        ('parcel', 'Parcel Delivery'),
        ('both', 'Food & Parcel Delivery'),
    ]
    
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='rider_profile'
    )
    phone_number = models.CharField(max_length=15, blank=True)
    vehicle_type = models.CharField(max_length=50, blank=True)
    is_available = models.BooleanField(default=True)
    rider_type = models.CharField(
        max_length=20,
        choices=RIDER_TYPE_CHOICES,
        default='food',
        help_text='Type of delivery service this rider provides'
    )

    def __str__(self):
        return f"Rider: {self.user.username} ({self.get_rider_type_display()})"


# 🔥 AUTO CREATE RIDER PROFILE
@receiver(post_save, sender=User)
def create_rider_profile(sender, instance, created, **kwargs):
    if created and instance.role == 'rider':
        RiderProfile.objects.create(user=instance)
