from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, RiderProfile


class UserRegistrationForm(UserCreationForm):
    role = forms.ChoiceField(
        choices=User._meta.get_field('role').choices,
        initial='customer',
        widget=forms.HiddenInput()
    )

    class Meta(UserCreationForm.Meta):
        model = User
        fields = UserCreationForm.Meta.fields + ('email',)


class RiderRegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = 'rider'   # 🔥 FORCE rider role
        if commit:
            user.save()
        return user

